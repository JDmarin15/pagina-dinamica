<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row vh-100 justify-content-center align-items-center" style="border: 1px ">
            <div class="col">
                <div class="form text-center" style="border: 1px;">
                <h1>Login Form</h1>
                <form method="post" action="./fuctions/fuction.php">
                    <div class="d-grid col-3 mx-auto">
                      <label for="exampleInputEmail1" class="form-label">Email address</label>
                      <input type="email" name="user"class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Correo o telefono">
                    </div>
                    <div class="d-grid col-3 mx-auto">
                      <label for="exampleInputPassword1" class="form-label">Password</label>
                      <input type="password" name="pass" class="form-control" id="exampleInputPassword1" placeholder="Contraseña">
                      <div id="passwordHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="d-grid col-2 mx-auto btn-block">
                      <input type="submit" name="submit" class="btn btn-primary" value="submit">
                    </div>
                    <br>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
